import React, { useState } from "react";
import { View,Alert, Text, StyleSheet, TextInput, TouchableOpacity, KeyboardAvoidingView, Platform, ScrollView } from "react-native";
import type { NativeStackScreenProps } from "@react-navigation/native-stack";
import type { RootStackParamList } from "../../App";
type Props = NativeStackScreenProps<RootStackParamList, 'Login'>;
const Loginscreen = ({navigation}: Props) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const handleLogin = () => {
        if (!email.trim() || !password.trim()){
            setError("Email and passowrd are required");
            return;
        }
        if (!email.includes('@') || !email.includes('.')){
            setError("Please enter a valid email address");
            return;
        }
        setError('');
        navigation.replace('TaskList')
    }
    return (
        <KeyboardAvoidingView
            style={styles.screen}
            behavior={Platform.OS === "ios" ? "padding" : undefined}
            >
            <ScrollView>
                <View style={styles.container}>
                    <View style={styles.header}>
                        <Text style={styles.title}>Task Management System</Text>
                        <Text style={styles.subtitle}>Task Management System portal</Text>
                    </View>
                    <View style={styles.divide} />
                    <Text style={styles.loginTitle}>Welcome Back</Text>
                    <Text style={styles.loginSubtitle}>Sign in to acess your account</Text>
                    <Text style={styles.label}>Email:</Text>
                    <TextInput
                        style={styles.input}
                        placeholder="Enter yoru Email"
                        onChangeText={setEmail}
                        value={email}
                        keyboardType="email-address"
                        autoCapitalize="none"
                        placeholderTextColor="#b1aaaa"
                    />
{error ? (
  <Text style={styles.errorText}>{error}</Text>
) : null}
                    <Text style={styles.label}>Password:</Text>
                    <TextInput
                        style={styles.input}
                        placeholder="Enter your Password"
                        value={password}
                        onChangeText={setPassword}
                        secureTextEntry
                        placeholderTextColor="#b1aaaa" 
                    />
                    <TouchableOpacity
                    onPress={()=> navigation.navigate("Signup")}>
                        <Text style={styles.signupText}>Don't have an account? Sign Up</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                        style={styles.button}
                        onPress={handleLogin}
                    >
                        <Text style={styles.buttonText}>LOGIN</Text>
                    </TouchableOpacity>
                    <Text style={styles.footerText}>
                        Multiple Task is to here
                    </Text>
                </View>
            </ScrollView>
        </KeyboardAvoidingView>
    )
}
const styles = StyleSheet.create({
    screen:{
        flex:1,
        backgroundColor:"#f1f1f1",
    },
    container: {
        flex: 1,
        padding: 20,
        borderRadius:18,
        shadowColor:"black",
        shadowOffset:{width:0,height:6},
        shadowRadius:10,
        shadowOpacity:1,
        elevation:8,
        margin: 2,
        width:"100%",
        maxWidth: 500,
        backgroundColor:"#ffff"
    },
    header:{
        alignItems:"center",
    },
    title: {
        fontWeight: "bold",
        fontSize:30,
        color: "#4f5964",
        textAlign: "center",
        justifyContent: "center",
    },
    subtitle:{
        marginTop:5,
        fontSize:15,
        color:"rgba(6, 48, 110, 0.71)",
        textAlign:"center",
    },
    divide:{
        height:3,
        backgroundColor:"rgba(87, 87, 98, 0.98)",
        marginVertical:30,
    },
    loginTitle:{
        fontSize:25,
        fontWeight:"bold",
        color:"rgba(88, 20, 144, 0.81)",
        marginBottom:5,
        textAlign:"center"
    },
    loginSubtitle:{
        fontSize:13,
        color:"grey",
        marginBottom:20,
        textAlign:"center",
    },
    label: {
        fontSize: 15,
        fontWeight: "600",
        color:"#454040",
        marginBottom:7,
        marginTop:10,
    },
    input:{
        height:50,
        borderWidth:1,
        borderRadius:9,
        borderColor:"black",
        paddingHorizontal:20,
        backgroundColor:"white",
        color:"#010428ae",
        fontSize:15,
    },
    button: {
        borderCurve: "circular",
        height:50,
        marginTop:25,
        marginBottom:15,
        borderRadius:9,
        backgroundColor:"#1846ef",
        justifyContent:"center",
        alignItems:"center",
        shadowColor:"#382fb4",
        shadowOffset:{width:0,height:5,},
        shadowOpacity:1,
        shadowRadius:6,
        elevation:5,
    },
    buttonText:{
        color:"#262323",
        fontSize:17,
        fontWeight:"bold",
        letterSpacing:1,
    },
    footerText:{
        fontSize:12,
        color:"#bbbaba",
        marginTop:25,
        textAlign:"center",  
    },
    errorText:{
        color:"red",
        fontSize:14,
        marginTop:6,
    },
    signupText:{
        color:"#1846ef",
        fontSize:15,
        fontWeight:"700",
        textAlign:"center",
        marginTop:20,
    },
})
export default Loginscreen;