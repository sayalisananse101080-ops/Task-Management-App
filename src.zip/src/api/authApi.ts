const BASE_URL = 'http://192.168.0.20:8000';

export const signupUser = async (userData: any) => {
    const payload = {
        name: userData.name,
        username: userData.username,
        email: userData.email,
        password: userData.password,

        address:{
            street: userData.street,
            suite: userData.suite,
            city: userData.city,
            zipcode: userData.zipcode,
        
        geo:{
            lat: userData.lat,
            lng: userData.lng,
        },
    },
        phone: userData.phone,
        website: userData.website,
        company:{
            name: userData.name,
            catchPhrase: userData.catchPhrase,
            bs: userData.bs,
        },
    };
    console.log('Signup payload:', JSON.stringify(payload, null, 2));
    
  const response = await fetch(`${BASE_URL}/users`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(userData),
  });
  const data = await response.json();

  if (!response.ok) {
    const message = Array.isArray(data.detail)
      ? data.detail.map((err: any) =>
          `${err.loc.join('.')}: ${err.msg}`
        ).join('\n')
      : data.detail || 'Registration failed';
    throw new Error(message);
  }
  return data;
};