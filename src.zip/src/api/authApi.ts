const BASE_URL = 'http://192.168.0.20:8000';
export const loginUser = async (
    email: string,
    password: string,
) => {
    const url = `${BASE_URL}/auth/login`;

    try {
        console.log('LOGIN URL:', url);

        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                Accept: 'application/json',
            },
            body: JSON.stringify({
                email: email.trim().toLowerCase(),
                password,
            }),
        });

        const data = await response.json();

        console.log('LOGIN STATUS:', response.status);

        if (!response.ok) {
            throw new Error(data.detail || 'Login failed');
        }

        return data;

    } catch (error) {
        console.log('LOGIN API ERROR:', error);
        throw error;
    }
};